import React from 'react'


//about component
const About = () => {
  return (
    <div className="about">
        <h1 className="about__title">About</h1>
        <p className="about__text">
            <span className="firstWord">Lorem</span> ipsum dolor sit amet, consectetur adipiscing elit.
            Pellentesque euismod, nisi vel consectetur euismod,
            nisl nisi consectetur nisi, euismod nisi nisi vel
            consectetur euismod, nisi vel consectetur euismod,
            nisl nisi consectetur nisi, euismod nisi nisi vel
            consectetur euismod, nisi vel consectetur euismod,
            nisl nisi consectetur nisi, euismod nisi nisi vel
            consectetur euismod, nisi vel consectetur euismod,
            nisl nisi consectetur nisi, euismod nisi nisi vel
            consectetur euismod, nisi vel consectetur euismod,
            nisl nisi consectetur nisi, euismod nisi nisi vel
            </p>
    </div>
  )
}

export default About